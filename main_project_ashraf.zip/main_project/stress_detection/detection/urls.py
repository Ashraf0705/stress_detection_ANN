# detection/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),                # Home page
    path('login/', views.login_view, name='login'),    # Login page
    path('signup/', views.signup_view, name='signup'), # Signup page
    path('parameters/', views.parameter_entry, name='parameters'), # Parameter entry page
    path('results/', views.results, name='results'),   # Results page
]
