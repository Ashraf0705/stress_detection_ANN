# detection/views.py

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required

def index(request):
    """Home page view"""
    return render(request, 'index.html')

def login_view(request):
    """Login view"""
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('parameters')  # Redirect to parameter entry page
        else:
            messages.error(request, 'Invalid username or password.')
    
    return render(request, 'login.html')

def signup_view(request):
    """Signup view with password validation"""
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']
        email = request.POST['email']
        
        if password != confirm_password:
            messages.error(request, 'Passwords do not match.')
        elif len(password) < 8:
            messages.error(request, 'Password must be at least 8 characters long.')
        elif User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists.')
        else:
            user = User.objects.create_user(username=username, password=password, email=email)
            user.save()
            messages.success(request, 'Account created successfully. Please log in.')
            return redirect('login')
    
    return render(request, 'signup.html')

@login_required
def parameter_entry(request):
    """View to enter stress parameters; requires login"""
    if request.method == 'POST':
        # Retrieve form data
        snoring_rate = int(request.POST.get('snoring_rate', 0))
        respiratory_rate = int(request.POST.get('respiratory_rate', 0))
        body_temp = float(request.POST.get('body_temp', 0))
        limb_movement = int(request.POST.get('limb_movement', 0))
        blood_oxygen = int(request.POST.get('blood_oxygen', 0))
        eye_movement = int(request.POST.get('eye_movement', 0))
        sleep_hours = int(request.POST.get('sleep_hours', 0))
        heart_rate = int(request.POST.get('heart_rate', 0))

        # Basic stress detection logic (adjust as needed)
        if (snoring_rate > 10 or respiratory_rate > 20 or body_temp > 37.5 or 
            limb_movement > 15 or blood_oxygen < 90 or eye_movement > 10 or 
            sleep_hours < 6 or heart_rate > 100):
            stress_level = "Detected"
        else:
            stress_level = "Not Detected"

        # Render results page with stress level
        return render(request, 'results.html', {'stress_level': stress_level})

    return render(request, 'parameter_entry.html')

def results(request):
    """Results page view"""
    # This view renders the results page directly
    stress_level = request.GET.get('stress_level', 'No Data')
    return render(request, 'results.html', {'stress_level': stress_level})
